POWER BI + MICROSOFT FABRIC PORTFOLIO

1. Open index.html in a browser to preview the website.
2. Edit the email and LinkedIn link in index.html.
3. Replace project placeholders with your actual dashboard screenshots when ready.
4. Publish using GitHub Pages, Netlify, or Vercel.

Files:
- index.html
- style.css
- script.js
